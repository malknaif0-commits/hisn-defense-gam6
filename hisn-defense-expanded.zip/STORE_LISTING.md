# بيانات صفحة المتجر (Google Play)

## العربية

**اسم التطبيق** (حد أقصى 30 حرف)
حصن الدفاع

**وصف قصير** (حد أقصى 80 حرف)
دافع عن حصنك من موجات الجنود والدبابات. ابنِ أبراج وطوّرها.

**الوصف الكامل**
حصن الدفاع لعبة استراتيجية بسيطة وسريعة. الأعداء يمشون في الطريق باتجاه حصنك، وعليك توقفهم قبل ما يوصلون.

- 3 أنواع أبراج: رشاش سريع، مدفع بضرر منطقة، وقناص بعيد المدى
- طوّر كل برج لثلاث مستويات، أو بِعه واسترجع جزء من تكلفته
- جنود ودراجات وجيبات ودبابات، وزعيم كل 10 موجات
- موجات لا تنتهي، وكل موجة أصعب من اللي قبلها
- تسريع اللعب x2، وصوت يتحكم فيه
- تشتغل بدون إنترنت، وبدون إعلانات

## English

**App name:** Fort Defense

**Short description:** Defend your fort against waves of soldiers and tanks. Build and upgrade towers.

**Full description**
Fort Defense is a fast, simple tower defense game. Enemies march along the road toward your fort, and you must stop them before they arrive.

- 3 tower types: fast machine gun, area-damage cannon, long-range sniper
- Upgrade each tower up to 3 levels, or sell it for a partial refund
- Soldiers, bikes, jeeps and tanks, with a boss every 10 waves
- Endless waves that get harder each time
- 2x speed button and sound effects
- Works offline, no ads

## إعدادات Play Console

- نوع التطبيق: لعبة (Game) ← استراتيجية (Strategy)
- مجاني
- التصنيف العمري: عبّي الاستبيان بصدق. اللعبة فيها قتال كرتوني بسيط بدون دم.
- Data safety: لا تجمع ولا تشارك أي بيانات
- فيها إعلانات؟ لا
- الصور المطلوبة: أيقونة 512×512 (موجودة في www/icon-512.png)، وصورة Feature graphic بمقاس 1024×500، ولقطتين شاشة على الأقل. خذ اللقطات من اللعبة نفسها وهي شغالة.
