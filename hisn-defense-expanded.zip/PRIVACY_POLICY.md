# سياسة الخصوصية - حصن الدفاع

آخر تحديث: 1 نوفمبر 2026

لعبة "حصن الدفاع" لا تجمع ولا تخزن ولا تشارك أي بيانات شخصية.

- ما نطلب منك اسم أو بريد أو رقم جوال.
- ما نستخدم موقعك ولا الكاميرا ولا الميكروفون.
- ما فيه إعلانات ولا أدوات تتبع ولا تحليلات من أطراف ثالثة.
- اللعبة تحفظ على جهازك فقط رقم أفضل موجة وصلت لها، وهذا الرقم ما يطلع من جهازك. تنحذف لما تحذف اللعبة.

إذا غيّرنا هذي السياسة بنحدّث هذي الصفحة.

للتواصل: [ضع بريدك هنا]

---

# Privacy Policy - Fort Defense

Last updated: November 1, 2026

Fort Defense does not collect, store or share any personal data.

- We do not ask for your name, email or phone number.
- We do not use your location, camera or microphone.
- There are no ads, trackers or third-party analytics.
- The game stores only your best wave number on your own device. It never leaves your device and is removed when you uninstall the game.

If this policy changes, we will update this page.

Contact: [put your email here]
